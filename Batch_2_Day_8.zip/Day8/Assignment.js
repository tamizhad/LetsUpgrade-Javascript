let products = [
    {
      id: 1,
      name: "Red Gown",
      size: "L",
      color: "Red",
      price: 1200,
      image: "picture1.jpg",
      description: "Red Gown",
    },
    {
      id: 2,
      name: "Frown",
      size: "M",
      color: "Pure red",
      price: 1500,
      image: "picture2.jpg",
      description: "Good looking Red Suite",
    },
  
    {
      id: 3,
      name: "Fashion Overcoat Top",
      size: "S",
      color: "White & Orange",
      price: 900,
      image: "picture3.jpg",
      description: "Good looking White salvar",
    },
  
    {
      id: 4,
      name: "Female Blazer",
      size: "M",
      color: "REd and peach yellow",
      price: 3000,
      image: "picture4.jpg",
      description: "Beautifull Blazer",
    },
  
    {
      id: 5,
      name: "Yellow Red Top",
      size: "S",
      color: "Yellow",
      price: 1300,
      image: "picture5.jpg",
      description: "Good looking Top",
    },
  
    {
      id: 6,
      name: "Indian Dress",
      size: "M",
      color: "Henna",
      price: 1500,
      image: "picture6.jpg",
      description: "Good looking Traditional Dress",
    },
    {
      id: 7,
      name: "Red Gownee",
      size: "L",
      color: "Red",
      price: 12000,
      image: "picture1.jpg",
      description: "Red Gown",
    },
    {
      id: 8,
      name: "Frownthe",
      size: "M",
      color: "Pure red",
      price: 1900,
      image: "picture2.jpg",
      description: "Good looking Red Suite",
    },
  
    {
      id: 9,
      name: "Fashion Overcoat Top cover",
      size: "S",
      color: "White & Orange",
      price: 2900,
      image: "picture3.jpg",
      description: "Good looking White salvar",
    },
  
    {
      id: 10,
      name: "Female Blazereee",
      size: "M",
      color: "REd and peach yellow",
      price: 3300,
      image: "picture4.jpg",
      description: "Beautifull Blazer",
    },
  
    {
      id: 11,
      name: "Yellow Red Topeee",
      size: "S",
      color: "Yellow",
      price: 1600,
      image: "picture5.jpg",
      description: "Good looking Top",
    },
  
    {
      id: 12,
      name: "Indian Dresseerr",
      size: "M",
      color: "Henna",
      price: 15000,
      image: "picture6.jpg",
      description: "Good looking Traditional Dress",
    },
  ];
  
  cart = [];
  
  function displayProducts(productsData, who = "productwrapper") {
    let productsString = "";
  
    productsData.forEach(function (product, index) {
      let { id, name, image, color, description, price, size } = product;
  
      if (who == "productwrapper") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="Pictures/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>Size : ${size}</p>
          <p>Color : ${color}</p>
          <p>${description}</p>
          <p>
          <button onclick="addToCart(${id})">Add to Cart</button>
          </p>
       </div>`;
      } else if (who == "cart") {
        productsString += ` <div class="product">
          <div class="prodimg">
            <img src="Pictures/${image}" width="100%" />
          </div>
          <h3>${name}</h3>
          <p>Price : ${price}$</p>
          <p>Size : ${size}</p>
          <p>Color : ${color}</p>
          <p>${description}</p>
          <p>
            <button onclick="removeFromCart(${id})">Remove from Cart</button>
          </p>
        </div>`;
      }
    });
  
    document.getElementById(who).innerHTML = productsString;
  }
  
  displayProducts(products);
  
  function searchProduct(searchValue) {
    let searchedProducts = products.filter(function (product, index) {
      let searchString =
        product.name + " " + product.color + " " + product.description;
  
      return searchString.toUpperCase().indexOf(searchValue.toUpperCase()) != -1;
    });
  
    displayProducts(searchedProducts);
  }
    function getProductByID(productArray, id) {
    return productArray.find(function (product) {
      return product.id == id;
    });
  }
  function filterProduct() {
    let  newproduct = products.filter(function(product) {
         //  if(product.price >= min.value && product.price <= max.value)
         //  {
         //   console.log(product)
         //   console.log(filteredProducts.product)
           
         //  }
         return product.price >= min.value && product.price <= max.value
    });        
    displayProducts(newproduct);
}
  function addToCart(id) {
    // getting the product
    let pro = getProductByID(products, id);
    const existing = cart.find(item => item.id === pro.id) 
    if(existing){ 
        alert('Item is already added to the cart'); 
        } else {
           //   putting in cart
        cart.push(pro);
        localStorage.setItem('cartItems', JSON.stringify(cart))
        count = cart.length;
        document.getElementsByClassName('count')[0].innerHTML = count;
        }
    
    displayProducts(cart, "cart");
  }
  

  function removeFromCart(id) {
    // getting the index based on id
    let index = cart.findIndex(function (product) {
      return product.id == id;
    });
  
    //   removing from cart based on index
    cart.splice(index, 1);
    displayProducts(cart, "cart");
  }
  

