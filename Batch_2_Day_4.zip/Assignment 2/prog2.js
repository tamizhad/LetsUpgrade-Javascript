function Inputbutton()
{
    // let a = document.getElementById(a2);
    // let b = document.getElementById(a223);
    // b.value = a.value;
    document.getElementById('a223').value = document.getElementById('a2').value;
}