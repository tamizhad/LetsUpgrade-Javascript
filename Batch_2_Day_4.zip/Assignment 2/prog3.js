let craft = [
    {
    name:"shina",
    age: 50,
    country: "USA",
    hobbies_array: {
    Indoor: "carrom",
    outdoor: "badmiton",
  },
},
{
    name:"mariya",
    age: 30,
    country: "Africa",
    hobbies_array: {
    Indoor: "Chess",
    outdoor: "Tennis",
  },
},
{
    name:"Alira",
    age: 20,
    country: "London",
    hobbies_array: {
    Indoor: "Ludo",
    outdoor: "Cycling",
  },
},
{
  name:"Alya",
  age: 24,
  country: "India",
  hobbies_array: {
  Indoor: "App games",
  outdoor: "Cycling",
},
},
];
// craft.forEach(function (craft) {
//   console.log(craft);
// });

function prop(){
  console.log("Object details:");
        console.log(craft);
}
prop();
craft.forEach(function (craft) {
  if(craft.age < 30){
    console.log("Printing the details of object which has age less than 30");
    console.log(craft);
  }
  if(craft.country == "India")
  {
    console.log("Printing the details of object which has object which has India");
    console.log(craft);
  }
});

// Prop : function () {
//     craft.forEach(function (crafte) {
//           console.log(craft);
//         });
//     }
//     craft.Prop();
// printName:function yu() (){
//     console.log(craft);
// }
// craft.printName();